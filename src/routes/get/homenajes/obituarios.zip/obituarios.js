const { Router } = require('express')
const router = Router()
const cors = require('cors')
const autorizarUsuario = require('../../../auth/auth')
const mysqlConnection = require('../../../config/mysql')

router.get('/obituarios', cors(), async(req, res)=> {
    const {
        ciudad
    }=req.body
    console.log(ciudad);
    const query = `SELECT CONCAT(nombre1,' ',nombre2,' ',apellido1,' ',apellido2)nombreCompleto, DATE_FORMAT(hora_exequias, '%h:%i %p')hora_exequias, fecha_exequias, fecha_fallecimiento, nombre_sala, lugar_exequias, fecha_registro FROM olivos_obituarios WHERE obituario_visualizar = '${ciudad}' AND fecha_registro >= DATE_ADD(NOW(), INTERVAL -1 DAY) ORDER BY id DESC`
    mysqlConnection.query(query, (err, results) => { 
        if(!err){
            res.status(200).json({
                error: false,
                query: 'Query correctly executed.',
                message: results
            })
        }else{
            throw err;
        }
    })
    })

module.exports = router